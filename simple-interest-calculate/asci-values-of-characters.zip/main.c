
#include <stdio.h>

int main()
{
    char characater;
    printf("Enter a characater = ");
    scanf("%c",&characater);
    printf("The ASCI value of %c is %d",characater,characater);

    return 0;
}
